# Fito Investments App

Placeholder Next.js app for deployment.
