export default function Home(){
  return (
    <div style={{background:'#0a0f1f',color:'#00aaff',height:'100vh',display:'flex',justifyContent:'center',alignItems:'center',fontSize:'2rem'}}>
      Fito Investments – Neon Blue Crypto Style UI (placeholder)
    </div>
  )
}